import numpy as np
from abc import ABC, abstractmethod
from ase.data import covalent_radii
from ase.geometry import get_distances
from ase import Atoms

from ase.visualize import view

def check_valid_bondlengths(a, blmin=None, blmax=None, indices=None, check_too_close=True, check_isolated=True):
    """Calculates if the bondlengths between atoms with indices
    in 'indices' and all other atoms are valid. The validity is
    determined by blmin and blmax.

    Parameters:

    a: Atoms object

    blmin: The minimum allowed distance between atoms in units of
    the covalent distance between atoms, where d_cov=r_cov_i+r_cov_j.
    
    blmax: The maximum allowed distance, in units of the covalent 
    distance, from a single isolated atom to the closest atom. If
    blmax=None, no constraint is enforced on isolated atoms.

    indices: The indices of the atoms of which the bondlengths
    with all other atoms is checked. if indices=None all bondlengths
    are checked.
    """
    bl = get_distances_as_fraction_of_covalent(a,indices)
    
    # Filter away self interactions.
    bl = bl[bl > 1e-6].reshape(bl.shape[0],bl.shape[1]-1)
    
    # Check if atoms are too close
    if blmin is not None and check_too_close:
        tc = np.any(bl < blmin)
    else:
        tc = False
        
    # Check if there are isolated atoms
    if blmax is not None and check_isolated:
        isolated = np.any(np.all(bl > blmax, axis=1))
    else:
        isolated = False
        
    is_valid = not tc and not isolated
    return is_valid
    
def get_distances_as_fraction_of_covalent(a, indices=None, covalent_distances=None):
    if indices is None:
        indices = np.arange(len(a))
        
    if covalent_distances is None:
        cd = get_covalent_distance_from_atom_numbers(a, indices=indices)
    else:
        cd = covalent_distances[indices,:]
    _, d = get_distances(a[indices].positions,
                         a.positions,
                         cell=a.get_cell(),
                         pbc=a.get_pbc())
    bl = d/cd
    return bl

def get_covalent_distance_from_atom_numbers(a, indices=None):
    r_cov = np.array([covalent_radii[n] for n in a.get_atomic_numbers()])
    if indices is None:
        r_cov_sub = r_cov
    else:
        r_cov_sub = r_cov[indices]
    cd_mat = r_cov_sub.reshape(-1,1) + r_cov.reshape(1,-1)
    return cd_mat

def get_min_distances_as_fraction_of_covalent(a, indices=None, covalent_distances=None):
    bl = get_distances_as_fraction_of_covalent(a,indices)
    
    # Filter away self interactions.
    bl = bl[bl > 1e-6].reshape(bl.shape[0],bl.shape[1]-1)
    
    return np.min(bl), bl.min(axis=1).argmin()